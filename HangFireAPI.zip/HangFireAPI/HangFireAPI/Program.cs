using Hangfire;
using HangFireAPI.Models;
using HangFireAPI.Repositories;
using HangFireAPI.Repositories.Interfaces;
using Microsoft.Data.SqlClient;
using Microsoft.AspNetCore.Mvc;
using System.Data;

var builder = WebApplication.CreateBuilder(args);
var connectionString = builder.Configuration["ConnectionStrings:SqlServer"];

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddHangfire(config => config
    .UseSqlServerStorage(connectionString));

builder.Services.AddHangfireServer();
builder.Services.AddSingleton<IDbConnection>(sp => new SqlConnection(connectionString));
builder.Services.AddSingleton<IUserRepository, UserRepository>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseHangfireDashboard();
app.MapPost("usuarios/agendar", (IUserRepository userRepository, [FromBody] User user) =>
{
    BackgroundJob.Schedule(() => userRepository.UserInsert(user.Name, user.Email), TimeSpan.FromMinutes(1));
    return Results.Ok("Usu�rio agendado para inser��o daqui a 1 minuto!");
});
app.UseAuthorization();

app.MapControllers();
app.MapPost("usuarios/enfileirar", (IUserRepository userRepository, [FromBody] User user) =>
{
    BackgroundJob.Enqueue(() => userRepository.UserInsert(user.Name, user.Email));
    return Results.Ok("Usu�rio enfileirado para inser��o imediata!");

});

app.Run();

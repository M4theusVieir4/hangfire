﻿using Dapper;
using HangFireAPI.Repositories.Interfaces;
using System.Data;

namespace HangFireAPI.Repositories
{
    public class UserRepository(IDbConnection dbConnection) : IUserRepository
    {
        public void UserInsert(string name, string email)
        {
            var sql = "INSERT INTO Usuarios (Nome, Email) VALUES (@Nome, @Email)";

            dbConnection.Execute(sql, param: new
            {
                Nome = name,
                Email = email
            });
        }
    }
}
